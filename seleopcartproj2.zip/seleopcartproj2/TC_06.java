import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;

public class TC_06 {
	WebDriver driver;  
	@BeforeMethod
	public void setup() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		 driver =new ChromeDriver();
		driver.manage().window().maximize();
		 driver.get("http://localhost/opencartsite/");
	}
	
	 @Test(priority=1)
	 public void Login() throws Exception {
	 driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
	 driver.findElement(By.linkText("Login")).click();
	 FileInputStream f1= new FileInputStream("D:\\opencart.xls");
     Workbook w= Workbook.getWorkbook(f1);
     Sheet s=w.getSheet(0);
     String Email=s.getCell(2,0).getContents();
     String pass=s.getCell(4,0).getContents();
     
     driver.findElement(By.name("email")).sendKeys(Email);
     driver.findElement(By.name("password")).sendKeys(pass);
     driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
     Thread.sleep(5000);
     String title=driver.getTitle();
     Assert.assertEquals(title,"My Account","title not matched");
     }
	 @Test(priority=2)
	 public void Search() throws Exception {
		 driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a/span[1]")).click();
		 driver.findElement(By.linkText("Login")).click();
		 FileInputStream f1= new FileInputStream("D:\\opencart.xls");
	     Workbook w= Workbook.getWorkbook(f1);
	     Sheet s=w.getSheet(0);
	     String Email=s.getCell(2,0).getContents();
	     String pass=s.getCell(4,0).getContents();
	     
	     driver.findElement(By.name("email")).sendKeys(Email);
	     driver.findElement(By.name("password")).sendKeys(pass);
	     driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
	     Thread.sleep(5000);
		 driver.findElement(By.name("search")).sendKeys("canon");
		 driver.findElement(By.xpath("//*[@id=\"search\"]/span/button/i")).click();
		 driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div/div/div[1]/a/img")).click();//to click canon image
		 new Select(driver.findElement(By.id("input-option226"))).selectByValue("15");
		 driver.findElement(By.name("quantity")).clear();
		 driver.findElement(By.name("quantity")).sendKeys("10");
		 driver.findElement(By.id("button-cart")).click();
		 driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		 driver.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]/a[2]")).click();
		 System.out.println("Total"+(driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/table/tbody/tr/td[6]")).getText()));
		 boolean b=driver.findElement(By.xpath("//*[@id=\"content\"]/h1")).isDisplayed();
		 Assert.assertTrue(b);
		 Assert.assertEquals(true, b);
	 }  
     @AfterMethod() 
        public void teardown() {
        driver.close();
        }
}
}
	

